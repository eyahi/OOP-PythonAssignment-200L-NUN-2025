class Guest:
    def __init__(self, name, contact):
        self.name = name
        self.contact = contact