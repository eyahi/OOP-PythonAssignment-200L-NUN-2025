class Reservation:
    def __init__(self, room, guest, check_in, check_out):
        self.room = room
        self.guest = guest
        self.check_in = check_in
        self.check_out = check_out