
import tkinter as tk
from tkinter import messagebox
import json

# -------------------- Data Classes --------------------
from room import Room
from guest import Guest
from reservation import Reservation

# -------------------- Hotel Management Logic --------------------
class Hotel:
    def __init__(self):
        self.rooms = {}
        self.reservations = {}

    def add_room(self, number, room_type, price):
        if number not in self.rooms:
            self.rooms[number] = Room(number, room_type, price)

    def get_room(self, number):
        return self.rooms.get(number)

    def book_room(self, number, guest, check_in, check_out):
        room = self.get_room(number)
        if room and room.available:
            self.reservations[number] = Reservation(room, guest, check_in, check_out)
            room.available = False
            return True
        return False

    def cancel_booking(self, number):
        if number in self.reservations:
            self.reservations[number].room.available = True
            del self.reservations[number]

    def available_rooms(self):
        return [room for room in self.rooms.values() if room.available]

    def save_data(self):
        data = {
            "rooms": [{"number": r.number, "type": r.room_type, "price": r.price, "available": r.available} for r in self.rooms.values()],
            "reservations": [{
                "room": res.room.number,
                "guest": {"name": res.guest.name, "contact": res.guest.contact},
                "check_in": res.check_in,
                "check_out": res.check_out
            } for res in self.reservations.values()]
        }
        with open("hotel_data.json", "w") as f:
            json.dump(data, f)

    def load_data(self):
        try:
            with open("hotel_data.json", "r") as f:
                data = json.load(f)
            for r in data["rooms"]:
                room = Room(r["number"], r["type"], r["price"])
                room.available = r["available"]
                self.rooms[r["number"]] = room
            for res in data["reservations"]:
                guest = Guest(res["guest"]["name"], res["guest"]["contact"])
                room = self.rooms[res["room"]]
                self.reservations[res["room"]] = Reservation(room, guest, res["check_in"], res["check_out"])
        except FileNotFoundError:
            pass

# -------------------- GUI Application --------------------
class HotelApp:
    def __init__(self, root, hotel):
        self.hotel = hotel
        self.root = root
        self.root.title("Hotel Management System")
        self.root.geometry("500x600")
        self.root.configure(bg="#f0f0f0")

        self.main_frame = tk.Frame(root, bg="#f0f0f0")
        self.main_frame.pack(pady=20)

        tk.Label(self.main_frame, text="Hotel Management System", font=("Helvetica", 16, "bold"), bg="#f0f0f0").pack(pady=10)

        self._add_button("Add Room", self.add_room_ui)
        self._add_button("Book Room", self.book_room_ui)
        self._add_button("Cancel Booking", self.cancel_ui)
        self._add_button("Show Available Rooms", self.show_available_rooms)
        self._add_button("Save and Exit", self.save_and_exit)

        tk.Label(self.main_frame, text="Available Rooms:", font=("Helvetica", 12, "bold"), bg="#f0f0f0").pack(pady=10)
        self.room_listbox = tk.Listbox(self.main_frame, width=60, height=10, font=("Courier", 10))
        self.room_listbox.pack(pady=5)
        self.show_available_rooms()

    def _add_button(self, text, command):
        tk.Button(self.main_frame, text=text, command=command, font=("Helvetica", 12), width=25, bg="#4CAF50", fg="white", bd=0).pack(pady=5)

    def add_room_ui(self):
        self._popup_form("Add Room", ["Number", "Type", "Price"], self._add_room_action)

    def _add_room_action(self, values):
        self.hotel.add_room(values[0], values[1], float(values[2]))
        messagebox.showinfo("Added", "Room added successfully")
        self.show_available_rooms()

    def book_room_ui(self):
        self._popup_form("Book Room", ["Room Number", "Guest Name", "Contact", "Check-in", "Check-out"], self._book_room_action)

    def _book_room_action(self, values):
        guest = Guest(values[1], values[2])
        success = self.hotel.book_room(values[0], guest, values[3], values[4])
        if success:
            messagebox.showinfo("Booked", "Room booked successfully")
        else:
            messagebox.showerror("Error", "Room not available or doesn't exist")
        self.show_available_rooms()

    def cancel_ui(self):
        self._popup_form("Cancel Booking", ["Room Number"], self._cancel_action)

    def _cancel_action(self, values):
        self.hotel.cancel_booking(values[0])
        messagebox.showinfo("Cancelled", "Booking cancelled")
        self.show_available_rooms()

    def _popup_form(self, title, labels, callback):
        popup = tk.Toplevel(self.root)
        popup.title(title)
        popup.geometry("300x400")
        entries = []
        for label in labels:
            tk.Label(popup, text=label).pack()
            entry = tk.Entry(popup)
            entry.pack()
            entries.append(entry)

        def submit():
            values = [e.get() for e in entries]
            callback(values)
            popup.destroy()

        tk.Button(popup, text="Submit", command=submit, bg="#4CAF50", fg="white").pack(pady=10)

    def show_available_rooms(self):
        self.room_listbox.delete(0, tk.END)
        rooms = self.hotel.available_rooms()
        for room in rooms:
            self.room_listbox.insert(tk.END, f"Room {room.number} | {room.room_type} | ${room.price:.2f}")
        if not rooms:
            self.room_listbox.insert(tk.END, "No rooms available")

    def save_and_exit(self):
        self.hotel.save_data()
        self.root.quit()

# -------------------- Run the Application --------------------
if __name__ == "__main__":
    hotel = Hotel()
    hotel.load_data()
    root = tk.Tk()
    app = HotelApp(root, hotel)
    root.mainloop()
